#include "minesweeper.h"
#include "ui_minesweeper.h"
#include<QPainter>
#include<algorithm>
#include<ctime>
#include<QTimer>
#include<QString>
#include<QDebug>
#include<QValidator>

Minesweeper::Minesweeper(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::Minesweeper)
{
    ui->setupUi(this);
    init();

}

void Minesweeper::init(){
    images.load(":/images/beijing.png");
    QPainter pen(&maptemp);
    images=images.scaled(690,650,Qt::IgnoreAspectRatio,Qt::SmoothTransformation);
    pen.drawImage(0,0,images);//画入背景图片

    QIcon queding(":/images/queding.png");
    this->ui->pushButton1->setIcon(queding);
    this->ui->pushButton1->setIconSize(QSize(190,65));//插入确定按钮图片
    this->ui->pushButton1->setFlat(true);//使按钮透明

    QIcon qvxiao(":/images/qvxiao.png");
    this->ui->pushButton2->setIcon(qvxiao);
    this->ui->pushButton2->setIconSize(QSize(190,65));//插入取消按钮图片
    this->ui->pushButton2->setFlat(true);//使按钮透明


    QIntValidator *validator1 = new QIntValidator(0, 100, this);//设置文本框文本格式，限制大小
    this->ui->lineEdit1->setValidator(validator1);

    QIntValidator *validator2 = new QIntValidator(0, 100, this);
    this->ui->lineEdit2->setValidator(validator2);

    QIntValidator *validator3 = new QIntValidator(0, 100, this);
    this->ui->lineEdit3->setValidator(validator3);
}


void Minesweeper::paintEvent(QPaintEvent*w){
    Q_UNUSED(w);
    QPainter pen(this);
    pen.drawPixmap(0,0,maptemp);

}

void Minesweeper::on_pushButton2_clicked()//点击取消时调用
{
    this->close();
}//关闭自定义窗口

void Minesweeper::on_pushButton1_clicked()//点击确定时调用
{
    QString linenumber=this->ui->lineEdit1->text();
    QString columnnumber=this->ui->lineEdit2->text();
    QString mines=this->ui->lineEdit3->text();
    this->close();//得到行数列数雷数，储存在三个QString对象中（后期调用数据），点击确定关闭自定义窗口
}

Minesweeper::~Minesweeper()
{
    delete ui;
}











