#ifndef MINESWEEPER_H
#define MINESWEEPER_H
#include <QMainWindow>
#include <QPaintEvent>
#include <QImage>
#include <QMouseEvent>
#include <QTimer>
#include <QString>
#include <QPainter>
using namespace std;

namespace Ui {
class Minesweeper;
}

class Minesweeper : public QMainWindow
{
    Q_OBJECT

public:
    QImage images;
    QPixmap maptemp=QPixmap(1920,1080);

    void init();
    void paintEvent(QPaintEvent*w);

    explicit Minesweeper(QWidget *parent = 0);
    ~Minesweeper();

private slots:

    void on_pushButton2_clicked();

    void on_pushButton1_clicked();

private:
    Ui::Minesweeper *ui;
};

#endif // MINESWEEPER_H
